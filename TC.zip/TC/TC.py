import tkinter as tk
import random
class PopupManager:
    def __init__(self):
        self.popup_count = 0
        self.max_popups = 80
        self.root = tk.Tk()
        self.root.withdraw() 
    def create_popup(self):
        if self.popup_count >= self.max_popups:
            return
        popup = tk.Toplevel(self.root)
        popup.title("袁子朋提醒你")
        popup.geometry("300x150")
        screen_width = popup.winfo_screenwidth()
        screen_height = popup.winfo_screenheight()
        window_width = 300
        window_height = 150
        x = random.randint(0, screen_width - window_width)
        y = random.randint(0, screen_height - window_height)
        popup.geometry(f"+{x}+{y}")
        popup.attributes('-topmost', True)
        colors = [
            'pink', 'lightpink', 'hotpink', 'deeppink', 'palevioletred',
            'red', 'darkred', 'firebrick', 'crimson', 'indianred',
            'blue', 'lightblue', 'deepskyblue', 'dodgerblue', 'royalblue', 
            'navy', 'steelblue', 'cornflowerblue',
            'green', 'lightgreen', 'limegreen', 'forestgreen', 'seagreen',
            'mediumseagreen', 'springgreen',
            'purple', 'mediumpurple', 'darkorchid', 'blueviolet', 'darkviolet',
            'orange', 'gold', 'yellow', 'khaki', 'coral', 'tomato',
            'cyan', 'turquoise', 'teal', 'slategray'
        ]
        messages = [
            '多喝水',
            '别熬夜',
            '记得吃早饭',
            '我很想你',
            '要天天开心',
            '早点睡',
            '照顾好自己',
            '天冷了多穿衣',
            '顺顺利利',
            '金榜题名',
            '保持微笑'
        ]
        bg_color = random.choice(colors)
        message = random.choice(messages)
        popup.configure(bg=bg_color)
        try:
            rgb = popup.winfo_rgb(bg_color)
            brightness = (rgb[0] * 299 + rgb[1] * 587 + rgb[2] * 114) / 1000
            text_color = 'black' if brightness > 128 else 'white'
        except:
            light_colors = ['pink', 'lightpink', 'lightblue', 'lightgreen', 
                           'yellow', 'gold', 'khaki', 'cyan', 'turquoise', 'springgreen']
            text_color = 'black' if bg_color in light_colors else 'white'
        label = tk.Label(popup, text=message, 
                        font=("Microsoft YaHei", 16),
                        bg=bg_color,  
                        fg=text_color)  
        label.place(relx=0.5, rely=0.5, anchor='center')
        popup.after(10000, popup.destroy)
        popup.bind('<Key>', lambda e: popup.destroy())
        popup.bind('<Button>', lambda e: popup.destroy())
        self.popup_count += 1
        if self.popup_count < self.max_popups:
            self.root.after(100, self.create_popup) 
    def start(self):
        self.create_popup()
        self.root.mainloop()
if __name__ == "__main__":
    manager = PopupManager()
    manager.start()